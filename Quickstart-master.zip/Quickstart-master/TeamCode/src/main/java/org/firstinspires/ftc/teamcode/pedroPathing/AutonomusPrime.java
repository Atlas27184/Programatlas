package org.firstinspires.ftc.teamcode.pedroPathing;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@Autonomous(name = "AutonomusPrime", group = "DecodeAtlas")
public class AutonomusPrime extends OpMode {

    private Follower follower;
    private Timer pathTimer, opmodeTimer;
    private int pathState;
    private Paths paths; // Contém os 8 caminhos gerados

    @Override
    public void init() {
        // Inicializa temporizadores
        pathTimer = new Timer();
        opmodeTimer = new Timer();
        opmodeTimer.resetTimer();

        // Cria o seguidor (follower)
        follower = Constants.createFollower(hardwareMap);

        // Cria os caminhos do Pedro Pathing
        paths = new Paths(follower);

        // Define pose inicial conforme o início do seu Path1
        follower.setStartingPose(new Pose(56.0, 8.0, Math.toRadians(90)));
    }

    @Override
    public void init_loop() {}

    @Override
    public void start() {
        opmodeTimer.resetTimer();
        setPathState(0);
    }

    @Override
    public void loop() {
        // Atualiza posição do seguidor
        follower.update();

        // Atualiza o estado atual do caminho
        autonomousPathUpdate();

        // Envia informações ao Driver Hub
        telemetry.addData("Path State", pathState);
        telemetry.addData("X", follower.getPose().getX());
        telemetry.addData("Y", follower.getPose().getY());
        telemetry.addData("Heading", follower.getPose().getHeading());
        telemetry.update();
    }

    @Override
    public void stop() {}

    // Método que controla a sequência de paths
    public void autonomousPathUpdate() {
        switch (pathState) {
            case 0:
                follower.followPath(paths.Path1);
                setPathState(1);
                break;
            case 1:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path2);
                    setPathState(2);
                }
                break;
            case 2:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path3);
                    setPathState(3);
                }
                break;
            case 3:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path4);
                    setPathState(4);
                }
                break;
            case 4:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path5);
                    setPathState(5);
                }
                break;
            case 5:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path6);
                    setPathState(6);
                }
                break;
            case 6:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path7);
                    setPathState(7);
                }
                break;
            case 7:
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path8);
                    setPathState(8);
                }
                break;
            case 8:
                if (!follower.isBusy()) {
                    // Finaliza a sequência
                    setPathState(-1);
                }
                break;
        }
    }

    // Define o novo estado do caminho
    public void setPathState(int pState) {
        pathState = pState;
        pathTimer.resetTimer();
    }

    // ----------------------------------------------------------
    // Classe gerada pelo Pedro Pathing (suas curvas e linhas)
    // ----------------------------------------------------------
    public static class Paths {
        public PathChain Path1, Path2, Path3, Path4, Path5, Path6, Path7, Path8;

        public Paths(Follower follower) {
            Path1 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(56.000, 8.000),
                            new Pose(80.000, 77.000),
                            new Pose(57.000, 91.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(90), Math.toRadians(134))
                    .build();

            Path2 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(57.000, 91.000),
                            new Pose(63.000, 83.000),
                            new Pose(43.000, 84.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(136), Math.toRadians(180))
                    .build();

            Path3 = follower
                    .pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(43.000, 84.000),
                            new Pose(17.000, 84.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(180))
                    .build();

            Path4 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(17.000, 84.000),
                            new Pose(69.318, 82.109),
                            new Pose(57.000, 91.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(136))
                    .build();

            Path5 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(57.000, 91.000),
                            new Pose(101.000, 59.000),
                            new Pose(43.000, 60.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(136), Math.toRadians(180))
                    .build();

            Path6 = follower
                    .pathBuilder()
                    .addPath(new BezierLine(
                            new Pose(43.000, 60.000),
                            new Pose(17.000, 60.000)))
                    .setTangentHeadingInterpolation()
                    .build();

            Path7 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(17.000, 60.000),
                            new Pose(93.456, 59.209),
                            new Pose(57.000, 91.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(136))
                    .build();

            Path8 = follower
                    .pathBuilder()
                    .addPath(new BezierCurve(
                            new Pose(57.000, 91.000),
                            new Pose(70.968, 67.668),
                            new Pose(15.400, 70.000)))
                    .setLinearHeadingInterpolation(Math.toRadians(136), Math.toRadians(180))
                    .build();
        }
    }
}
